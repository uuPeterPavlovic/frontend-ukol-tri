/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu5g05-elements"),require("uu_plus4u5g02-elements"),require("react"),require("uu5g05-forms")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu_plus4u5g02","uu_plus4u5g02-app","uu5g05-elements","uu_plus4u5g02-elements","react","uu5g05-forms"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu5g05-elements"),require("uu_plus4u5g02-elements"),require("react"),require("uu5g05-forms")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu5g05-elements"],e["uu_plus4u5g02-elements"],e.react,e["uu5g05-forms"])
}(this,((e,t,n,r,o,i,s,u,a)=>(()=>{var l,c,p,m={938:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var r=n(94),o=n(12);const i=o.Z.TAG+"Bricks.",s={...o.Z,TAG:i,
Css:r.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_frontend_maing01-hi/uu_frontend_maing01-hi@0.1.0")}},12:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>i});var r=n(94);const o="UuFrontend.",i={TAG:o,
Css:r.Utils.Css.createCssModule(o.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_frontend_maing01-hi/uu_frontend_maing01-hi@0.1.0")}},640:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>s});var r=n(94),o=n(12);const i=o.Z.TAG+"Core.",s={...o.Z,TAG:i,
Css:r.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_frontend_maing01-hi/uu_frontend_maing01-hi@0.1.0")}},873:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>c});var r=n(119),o=n.n(r),i=n(94),s=n(781),u=n.n(s),a=n(640),l=n(426);const c=(0,i.createVisualComponent)({uu5Tag:a.Z.TAG+"RouteBar",propTypes:{},defaultProps:{},render(e){const[,t]=(0,
i.useRoute)(),n=[{children:Uu5g05.Utils.Element.create(i.Lsi,{import:l.Z,path:["Menu","home"]}),onClick:()=>t("home")},{children:Uu5g05.Utils.Element.create(i.Lsi,{import:l.Z,
path:["Menu","shoppinglistdetails"]}),onClick:()=>t("shoppinglistdetails")},{children:Uu5g05.Utils.Element.create(i.Lsi,{import:l.Z,path:["Menu","about"]}),onClick:()=>t("about"),collapsed:!0}]
;return Uu5g05.Utils.Element.create(u().RouteBar,o()({appActionList:n},e))}})},714:(e,t,n)=>{"use strict";n.r(t),n.d(t,{render:()=>P});var r=n(602),o=n(94),i=(n(918),
n(763)),s=n.n(i),u=n(781),a=n.n(u),l=n(640),c=n(834),p=n.n(c),m=n(923),d=n.n(m),g=n(24),f=n(938);const h=({screenSize:e})=>f.Z.Css.css({display:"flex",maxWidth:624,padding:"24px 0",margin:"0 auto",
flexWrap:"wrap",..."xs"===e?{justifyContent:"center",textAlign:"center"}:null}),U=()=>f.Z.Css.css({padding:"0 24px"}),b=({screenSize:e})=>f.Z.Css.css({flex:1,minWidth:"xs"===e?"100%":0}),y=(0,
o.createVisualComponent)({uu5Tag:f.Z.TAG+"WelcomeRow",propTypes:{left:o.PropTypes.node},defaultProps:{left:void 0},render(e){const{left:t,children:n}=e,[r]=(0,
o.useScreenSize)(),i=o.Utils.VisualComponent.getAttrs(e,h({screenSize:r}));return Uu5g05.Utils.Element.create("div",i,Uu5g05.Utils.Element.create("div",{className:U({screenSize:r})
},t),Uu5g05.Utils.Element.create("div",{className:b({screenSize:r})},n))}});var _=n(873),v=n(426);const E=()=>g.Z.Css.css({fontSize:48,lineHeight:"1em"});let k=(0,o.createVisualComponent)({
uu5Tag:g.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,o.useSession)(),n=o.Utils.VisualComponent.getAttrs(e)
;return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(_.Z,null),Uu5g05.Utils.Element.create(y,{left:Uu5g05.Utils.Element.create(d().PersonPhoto,{size:"xl",borderRadius:"none"})
},Uu5g05.Utils.Element.create(p().Text,{category:"story",segment:"heading",type:"h2"},Uu5g05.Utils.Element.create(o.Lsi,{import:v.Z,path:["Home","welcome"]})),t&&Uu5g05.Utils.Element.create(p().Text,{
category:"story",segment:"heading",type:"h2"},t.name)),Uu5g05.Utils.Element.create(y,{left:Uu5g05.Utils.Element.create(p().Icon,{icon:"mdi-human-greeting",className:E()})
},Uu5g05.Utils.Element.create(p().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{import:v.Z,path:["Home","intro"]}))),Uu5g05.Utils.Element.create(y,{
left:Uu5g05.Utils.Element.create(p().Icon,{icon:"mdi-monitor",className:E()})},Uu5g05.Utils.Element.create(p().Text,{category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{
import:v.Z,path:["Home","clientSide"]}))),Uu5g05.Utils.Element.create(y,{left:Uu5g05.Utils.Element.create(p().Icon,{icon:"mdi-server",className:E()})},Uu5g05.Utils.Element.create(p().Text,{
category:"story",segment:"body",type:"common"},Uu5g05.Utils.Element.create(o.Lsi,{import:v.Z,path:["Home","serverSide"]}))))}});k=(0,u.withRoute)(k,{authenticated:!0})
;const L=k,x=o.Utils.Component.lazy((()=>n.e(790).then(n.bind(n,790)))),w=o.Utils.Component.lazy((()=>n.e(701).then(n.bind(n,701)))),C=o.Utils.Component.lazy((()=>n.e(327).then(n.bind(n,327)))),A=o.Utils.Component.lazy((()=>n.e(180).then(n.bind(n,180)))),T={
"":{redirect:"home"},home:e=>Uu5g05.Utils.Element.create(L,e),shoppinglistdetails:e=>Uu5g05.Utils.Element.create(x,e),about:e=>Uu5g05.Utils.Element.create(w,e),
"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create(C,e),controlPanel:e=>Uu5g05.Utils.Element.create(A,e),"*":{redirect:"home"}},j=(0,o.createVisualComponent)({uu5Tag:l.Z.TAG+"Spa",
propTypes:{},defaultProps:{},render:()=>Uu5g05.Utils.Element.create(s().SpaProvider,{initialLanguageList:["en","cs"]},Uu5g05.Utils.Element.create(a().Spa,{routeMap:T}))})
;if(o.Environment.appVersion="0.1.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}
let S;function P(e){S=e,o.Utils.Dom.render(Uu5g05.Utils.Element.create(r.zj,null,Uu5g05.Utils.Element.create(j,null)),document.getElementById(e))}},426:(e,t,n)=>{"use strict";n.d(t,{Z:()=>u})
;var r=n(94),o=n(823);const i="uu_frontend_maing01-hi",s=e=>n(394)(`./${e}.json`);s.libraryCode=i,r.Utils.Lsi.setDefaultLsi(i,{en:o});const u=s},24:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s})
;var r=n(94),o=n(12);const i=o.Z.TAG+"Routes.",s={...o.Z,TAG:i,
Css:r.Utils.Css.createCssModule(i.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_frontend_maing01-hi/uu_frontend_maing01-hi@0.1.0")}},280:(e,t,n)=>{
var r=n(145),o="undefined"!=typeof document,i=((r?r.uri:o&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),s="/0.0.0/"
;(i=i.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===s&&(i=i.substr(0,i.length-7)+"/0.1.0/"),n.p=i,e.exports=n(714);var u=e.exports
;u&&"object"==typeof u&&("version"in u||Object.defineProperty(u,"version",{configurable:!0,value:"0.1.0"}),"name"in u||Object.defineProperty(u,"name",{configurable:!0,
value:"uu_frontend_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in u||Object.defineProperty(u,"namespace",{configurable:!0,value:"UuFrontend"}))},602:(e,t,n)=>{"use strict"
;var r,o=(r=n(321))&&"object"==typeof r&&"default"in r?r.default:r;function i(e){return i.warnAboutHMRDisabled&&(i.warnAboutHMRDisabled=!0,
console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),
o.Children.only(e.children)}i.warnAboutHMRDisabled=!1;var s=function e(){return e.shouldWrapWithAppContainer?function(e){return function(t){return o.createElement(i,null,o.createElement(e,t))}
}:function(e){return e}};s.shouldWrapWithAppContainer=!1;t.zj=i},394:(e,t,n)=>{var r={"./cs.json":[27,27],"./en.json":[823]};function o(e){if(!n.o(r,e))return Promise.resolve().then((()=>{
var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=r[e],o=t[0];return Promise.all(t.slice(1).map(n.e)).then((()=>n.t(o,19)))}o.keys=()=>Object.keys(r),o.id=394,
e.exports=o},145:t=>{"use strict";t.exports=e},321:e=>{"use strict";e.exports=u},918:e=>{"use strict";e.exports=n},94:e=>{"use strict";e.exports=t},834:e=>{"use strict";e.exports=i},389:e=>{
"use strict";e.exports=a},763:e=>{"use strict";e.exports=r},781:e=>{"use strict";e.exports=o},923:e=>{"use strict";e.exports=s},119:e=>{function t(){
return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e
},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,e.exports.default=e.exports},823:e=>{"use strict"
;e.exports=JSON.parse('{"appName":"Application Shopping Lists","About":{"header":"About application Shopping Lists","creatorsHeader":"Application creators","termsOfUse":"Terms of use"},"AboutContent":{"content":"<uu5string/>Demo application is a template for developing new applications.","technologiesContent":"<uu5string/>Other used technologies: <Uu5Elements.Link href=\'http://www.w3schools.com/html/default.asp\' target=\'_blank\'>Html5</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/css/default.asp\' target=\'_blank\'>CSS</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/js/default.asp\' target=\'_blank\'>JavaScript</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://getbootstrap.com\' target=\'_blank\'>Bootstrap</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://reactjs.org\' target=\'_blank\'>React</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://www.ruby-lang.org\' target=\'_blank\'>Ruby</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://puma.io\' target=\'_blank\'>Puma</Uu5Elements.Link> a <Uu5Elements.Link href=\'https://www.docker.com\' target=\'_blank\'>Docker</Uu5Elements.Link>. Application is operated in the <Uu5Elements.Link href=\'https://plus4u.net\' target=\'_blank\'>Plus4U</Uu5Elements.Link> internet service with the usage of <Uu5Elements.Link href=\'https://azure.microsoft.com\' target=\'_blank\'>Microsoft Azure</Uu5Elements.Link> cloud."},"ControlPanel":{"rightsError":"You do not have sufficient rights to display this component.","btNotConnected":"The application is not connected to a Business Territory."},"Home":{"welcome":"Welcome to the application SHOPPING LIST","intro":"<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of using. For application developing purposes they are suitable for modifying, copying and deleting. More about uuApp Structure see documentation&nbsp; <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuAppDevKit</Uu5Elements.Link>.","clientSide":"<uu5string/>Libraries <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/05ecbf4e8bca405290b1a6d4cee8813a/book\\" target=\\"_blank\\">uu5</Uu5Elements.Link> and <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/83c1406c4fc541dba975941424106318/book\\" target=\\"_blank\\">uuPlus4U5</Uu5Elements.Link> are used for developing of client side.","serverSide":"<uu5string/>It is necessary to initialize application workspace for running server side. See manual <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuApp Template Developer Guide</Uu5Elements.Link>"},"InitAppWorkspace":{"notAuthorized":"You do not have sufficient rights to use the application.","formHeader":"Initialize uuApp","formHeaderInfo":"<uu5string/>Your uuApp is running, but requires initialization. If you need help with filling up this form, see\\n<Uu5Elements.Link target=\\"_blank\\" href=\\"#\\">Documentation</Uu5Elements.Link>.","notAuthorizedForInit":"The application is running but it was not initialized yet and you do not have sufficient rights to do so.","uuBtLocationUriLabel":"uuBusinessTerritory location","uuBtLocationUriInfo":"Uri of the uuBt location where AWSC will be created","nameLabel":"Name","initialize":"Initialize"},"Menu":{"home":"Welcome","about":"About Application","shoppinglistdetails":"Overview of the shopping lists"}}')
}},d={};function g(e){var t=d[e];if(void 0!==t)return t.exports;var n=d[e]={exports:{}};return m[e](n,n.exports,g),n.exports}return g.m=m,g.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
;return g.d(t,{a:t}),t},c=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,g.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e
;if(16&t&&"function"==typeof e.then)return e}var n=Object.create(null);g.r(n);var r={};l=l||[null,c({}),c([]),c(c)]
;for(var o=2&t&&e;"object"==typeof o&&!~l.indexOf(o);o=c(o))Object.getOwnPropertyNames(o).forEach((t=>r[t]=()=>e[t]));return r.default=()=>e,g.d(n,r),n},g.d=(e,t)=>{
for(var n in t)g.o(t,n)&&!g.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},g.f={},g.e=e=>Promise.all(Object.keys(g.f).reduce(((t,n)=>(g.f[n](e,t),t)),[])),g.u=e=>"chunks/index/"+e+"-"+{
27:"e3bf406e8bbd27c886c1",180:"38141d6fe0d4386d128c",327:"8b6585bcd6b176354696",701:"ce183419ab162560a542",790:"6b1c770d0198372bc0e4"}[e]+".min.js",
g.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),p={},g.l=(e,t,n,r)=>{if(p[e])p[e].push(t);else{var o,i;if(void 0!==n)for(var s=document.getElementsByTagName("script"),u=0;u<s.length;u++){
var a=s[u];if(a.getAttribute("src")==e){o=a;break}}o||(i=!0,(o=document.createElement("script")).charset="utf-8",o.timeout=120,g.nc&&o.setAttribute("nonce",g.nc),o.src=e,
0!==o.src.indexOf(window.location.origin+"/")&&(o.crossOrigin="anonymous")),p[e]=[t];var l=(t,n)=>{o.onerror=o.onload=null,clearTimeout(c);var r=p[e];if(delete p[e],
o.parentNode&&o.parentNode.removeChild(o),r&&r.forEach((e=>e(n))),t)return t(n)},c=setTimeout(l.bind(null,void 0,{type:"timeout",target:o}),12e4);o.onerror=l.bind(null,o.onerror),
o.onload=l.bind(null,o.onload),i&&document.head.appendChild(o)}},g.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),
Object.defineProperty(e,"__esModule",{value:!0})},g.p="",(()=>{var e={826:0};g.f.j=(t,n)=>{var r=g.o(e,t)?e[t]:void 0;if(0!==r)if(r)n.push(r[2]);else{var o=new Promise(((n,o)=>r=e[t]=[n,o]))
;n.push(r[2]=o);var i=g.p+g.u(t),s=new Error;g.l(i,(n=>{if(g.o(e,t)&&(0!==(r=e[t])&&(e[t]=void 0),r)){var o=n&&("load"===n.type?"missing":n.type),i=n&&n.target&&n.target.src
;s.message="Loading chunk "+t+" failed.\n("+o+": "+i+")",s.name="ChunkLoadError",s.type=o,s.request=i,r[1](s)}}),"chunk-"+t,t)}};var t=(t,n)=>{var r,o,[i,s,u]=n,a=0;if(i.some((t=>0!==e[t]))){
for(r in s)g.o(s,r)&&(g.m[r]=s[r]);if(u)u(g)}for(t&&t(n);a<i.length;a++)o=i[a],g.o(e,o)&&e[o]&&e[o][0](),e[o]=0
},n=this.__webpack_jsonp_uu_frontend_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_frontend_maing01_hi_0_1_0_index||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),g(280)})()));